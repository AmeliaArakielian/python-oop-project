from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional
import json
import urllib.request
import urllib.error


@dataclass
class CharacterViewModel:
    """
    Чиста модель персонажа (DTO / ViewModel), підготовлена бізнес-логікою
    для відображення в GUI або CLI без залежності від формату сирого JSON.
    """
    id: str
    name: str
    title: str
    vision: str
    weapon: str
    rarity: int
    nation: str
    description: str
    skills: List[str] = field(default_factory=list)

    def format_card(self) -> str:
        stars = "★" * self.rarity
        skills_str = ", ".join(self.skills) if self.skills else "Немає даних"
        return (
            f"[{self.name}] ({stars}) — {self.title}\n"
            f"  Елемент: {self.vision} | Зброя: {self.weapon} | Регіон: {self.nation}\n"
            f"  Навички: {skills_str}\n"
            f"  Опис: {self.description}"
        )


class GenshinJsonParser:
    """
    Парсер бізнес-логіки: перетворює сирий словник JSON від API
    у валідний об'єкт CharacterViewModel.
    """
    @staticmethod
    def parse_character(char_id: str, raw_data: Dict[str, Any]) -> CharacterViewModel:
        # Витягуємо назви активних навичок, якщо вони є в JSON
        raw_skills = raw_data.get("skillTalents", [])
        skill_names = [
            skill.get("name", "Невідома навичка")
            for skill in raw_skills
            if isinstance(skill, dict) and "name" in skill
        ]

        return CharacterViewModel(
            id=char_id.lower(),
            name=raw_data.get("name", char_id.capitalize()),
            title=raw_data.get("title", "Мандрівник"),
            vision=raw_data.get("vision", "Невідомо"),
            weapon=raw_data.get("weapon", "Невідомо"),
            rarity=int(raw_data.get("rarity", 4)),
            nation=raw_data.get("nation", "Невідомо"),
            description=raw_data.get("description", "Опис відсутній."),
            skills=skill_names
        )


class GenshinApiClientStub:
    """
    Інфраструктурний клієнт / заглушка для отримання JSON з https://genshin.jmp.blue/
    Якщо інтернет недоступний або API не відповідає, повертає тестові JSON-дані.
    """
    BASE_URL = "https://genshin.jmp.blue"

    MOCK_DATA: Dict[str, Dict[str, Any]] = {
        "diluc": {
            "name": "Diluc",
            "title": "The Dark Side of Dawn",
            "vision": "Pyro",
            "weapon": "Claymore",
            "rarity": 5,
            "nation": "Mondstadt",
            "description": "The tycoon of a winery empire in Mondstadt, unmatched in every possible way.",
            "skillTalents": [
                {"name": "Tempered Sword"},
                {"name": "Searing Onslaught"},
                {"name": "Dawn"}
            ]
        },
        "ganyu": {
            "name": "Ganyu",
            "title": "Plenilune Gaze",
            "vision": "Cryo",
            "weapon": "Bow",
            "rarity": 5,
            "nation": "Liyue",
            "description": "The secretary at Yuehai Pavilion. The blood of the qilin, an illuminated beast, flows within her veins.",
            "skillTalents": [
                {"name": "Liutian Archery"},
                {"name": "Trail of the Qilin"},
                {"name": "Celestial Shower"}
            ]
        },
        "zhongli": {
            "name": "Zhongli",
            "title": "Vago Mundo",
            "vision": "Geo",
            "weapon": "Polearm",
            "rarity": 5,
            "nation": "Liyue",
            "description": "A mysterious expert contracted by the Wangsheng Funeral Parlor. Extremely knowledgeable in all things.",
            "skillTalents": [
                {"name": "Rain of Stone"},
                {"name": "Dominus Lapidis"},
                {"name": "Planet Befall"}
            ]
        }
    }

    def fetch_character_list(self) -> List[str]:
        try:
            req = urllib.request.Request(
                f"{self.BASE_URL}/characters",
                headers={"User-Agent": "Python-OOP-Project"}
            )
            with urllib.request.urlopen(req, timeout=3) as response:
                data = json.loads(response.read().decode("utf-8"))
                if isinstance(data, list):
                    return data
        except Exception:
            pass
        return list(self.MOCK_DATA.keys())

    def fetch_character_json(self, char_id: str) -> Optional[Dict[str, Any]]:
        clean_id = char_id.strip().lower()
        try:
            req = urllib.request.Request(
                f"{self.BASE_URL}/characters/{clean_id}",
                headers={"User-Agent": "Python-OOP-Project"}
            )
            with urllib.request.urlopen(req, timeout=3) as response:
                return json.loads(response.read().decode("utf-8"))
        except Exception:
            return self.MOCK_DATA.get(clean_id)


class CatalogService:
    """
    Фасад бізнес-логіки каталогу персонажів.
    Об'єднує отримання JSON, парсинг у модель та кешування готових ViewModel.
    """
    def __init__(self, api_client: Optional[GenshinApiClientStub] = None):
        self._api = api_client or GenshinApiClientStub()
        self._parser = GenshinJsonParser()
        self._cache: Dict[str, CharacterViewModel] = {}

    def get_available_ids(self) -> List[str]:
        return self._api.fetch_character_list()

    def get_character_model(self, char_id: str) -> Optional[CharacterViewModel]:
        clean_id = char_id.strip().lower()
        if clean_id in self._cache:
            return self._cache[clean_id]

        raw_json = self._api.fetch_character_json(clean_id)
        if not raw_json:
            return None

        model = self._parser.parse_character(clean_id, raw_json)
        self._cache[clean_id] = model
        return model