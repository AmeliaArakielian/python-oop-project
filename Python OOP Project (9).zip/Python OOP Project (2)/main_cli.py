from cli.cli_facade import CLI
from cli.command_strategy import CharacterCatalogStrategy
from core.characters import CharacterManager, GameCharacter

class AppContextStub:
    """Контекст додатка, що містить бізнес-логіку."""
    def __init__(self):
        self.char_mgr = CharacterManager()
        # Додаємо тестового персонажа для демонстрації
        self.char_mgr.characters["Aragorn"] = GameCharacter(
            name="Aragorn", uid="aragorn", title="King", description="Ranger of the North"
        )

def run_cli_app():
    print("=== Консольний інтерфейс додатка (Практична №12 - Каталог персонажів) ===")
    print("Доступні команди: list_chars, show_char <name>, create_char <name> <title>, save_data, exit")

    app_context = AppContextStub()
    cli = CLI(app_context)
    
    # Реєструємо стратегію
    cli.use_strategy(CharacterCatalogStrategy())

    while True:
        try:
            line = input("CLI > ")
            if not line.strip():
                continue
            if line.strip() == "exit":
                print("Вихід з консольного інтерфейсу.")
                break
            if line.strip() == "help":
                print("Команди: list_chars, show_char <name>, create_char <name> <title>, save_data, exit")
                continue
            
            result = cli.exec_command(line)
            if result:
                print(cli.display(result))
        except (KeyboardInterrupt, EOFError):
            print("\nВихід.")
            break

if __name__ == "__main__":
    run_cli_app()