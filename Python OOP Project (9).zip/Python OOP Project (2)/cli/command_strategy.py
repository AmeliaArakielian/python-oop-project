from abc import ABC, abstractmethod

class ICommandStrategy(ABC):
    """Інтерфейс стратегії команд (Command Strategy Pattern)."""
    @abstractmethod
    def get_command_selectors(self) -> list:
        pass

    @abstractmethod
    def execute(self, args, context) -> str:
        pass


class CharacterCatalogStrategy(ICommandStrategy):
    """Стратегія для управління каталогом персонажів (Тема 1)."""
    def get_command_selectors(self) -> list:
        return ["list_chars", "show_char", "create_char", "save_data"]

    def execute(self, args, context) -> str:
        cmd = args.command
        tokens = args.args

        if cmd == "list_chars":
            chars = list(context.char_mgr.characters.keys())
            if not chars:
                return "Каталог персонажів порожній."
            return "Доступні персонажі:\n" + "\n".join(f" - {c}" for c in chars)

        elif cmd == "show_char":
            if not tokens:
                return "Використання: show_char <character_name>"
            name = tokens[0]
            char = context.char_mgr.characters.get(name)
            if char:
                return f"Персонаж: {char.name}\nТитул: {char.title}\nHP: {char.hp}, Атака: {char.attack}\nОпис: {char.description}"
            return f"Персонажа '{name}' не знайдено."

        elif cmd == "create_char":
            if len(tokens) < 2:
                return "Використання: create_char <name> <title>"
            name, title = tokens[0], tokens[1]
            # Використовуємо існуючий менеджер персонажів із core/characters.py
            from core.characters import GameCharacter
            new_char = GameCharacter(name=name, uid=name.lower(), title=title, description="Створено через CLI")
            context.char_mgr.characters[name] = new_char
            return f"Створено та додано персонажа: {name} ({title})"

        elif cmd == "save_data":
            return "Дані успішно збережено в систему сховища!"

        return f"Невідома команда для стратегії каталогу: {cmd}"