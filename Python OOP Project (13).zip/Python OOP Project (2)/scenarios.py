from core.text import TextDocumentManager, ContainerComponent, LeafComponent
from core.characters import CharacterManager

def run_text_scenario():
    print("--- СЦЕНАРІЙ ВИКОРИСТАННЯ: Text System ---")
    doc_mgr = TextDocumentManager()
    
    # Додаємо розділ та абзац
    chapter1 = ContainerComponent("Вступ", "intro")
    chapter1.add_child(LeafComponent("Абзац 1", "Це перший тестовий абзац.", "p1"))
    doc_mgr.root.add_child(chapter1)
    
    print("Поточний шлях:", doc_mgr.get_pwd())
    print("Рендеринг всього документа:")
    print(doc_mgr.root.render(show_id=True))

def run_chars_scenario():
    print("--- СЦЕНАРІЙ ВИКОРИСТАННЯ: Characters System ---")
    char_mgr = CharacterManager()
    
    char_mgr.add_character("Воїн", "warrior_1")
    char_mgr.add_ability("Фаєрбол", "fireball", 35)
    char_mgr.assign_to_char("warrior_1", "fireball", "ability")
    
    print(f"Створено персонажа: {char_mgr.characters['warrior_1'].name}")
    print(f"Кількість здібностей: {len(char_mgr.characters['warrior_1'].abilities)}")

if __name__ == "__main__":
    run_text_scenario()
    print("\n" + "="*40 + "\n")
    run_chars_scenario()