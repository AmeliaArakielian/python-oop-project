# main_cli.py
from cli.cli_facade import CLI
from cli.command_strategy import CharacterCatalogStrategy
from core.characters import CharacterManager, GameCharacter
from core.catalog_service import CatalogService


class AppContextStub:
    """Контекст додатка, що об'єднує компоненти бізнес-логіки (CORE)."""
    def __init__(self):
        self.char_mgr = CharacterManager()
        self.char_mgr.characters["Aragorn"] = GameCharacter(
            name="Aragorn", uid="aragorn", title="King", description="Ranger of the North"
        )
        self.catalog_service = CatalogService()


def run_cli_app():
    print("=== Консольний інтерфейс додатка (Практичні №12 та №14 - Каталог персонажів) ===")
    print("Команди локальні: list_chars, show_char <name>, create_char <name> <title>")
    print("Команди API (JSON парсинг): api_list, api_parse <id> (напр. diluc, ganyu, zhongli)")
    print("Системні: save_data, help, exit")

    app_context = AppContextStub()
    cli = CLI(app_context)
    cli.use_strategy(CharacterCatalogStrategy())

    while True:
        try:
            line = input("CLI > ")
            if not line.strip():
                continue
            if line.strip() == "exit":
                print("Вихід з консольного інтерфейсу.")
                break
            if line.strip() == "help":
                print("Доступні команди: list_chars, show_char <name>, create_char <name> <title>, api_list, api_parse <id>, save_data, exit")
                continue

            result = cli.exec_command(line)
            if result:
                print(cli.display(result))
        except (KeyboardInterrupt, EOFError):
            print("\nВихід.")
            break


if __name__ == "__main__":
    run_cli_app()