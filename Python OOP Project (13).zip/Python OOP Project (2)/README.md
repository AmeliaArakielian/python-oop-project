# Genshin Impact Character Catalog (OOP Project)

Консольний та графічний додаток на Python, що реалізує тришарову архітектуру (Presentation, Business Logic, Persistence/Data) із використанням патернів проєктування (Facade, Strategy, State, DTO).

## Вимоги до системи
* Python версії 3.10 або вище.
* Інтернет-з'єднання (для первинного завантаження даних із [Genshin Impact API](https://genshin.jmp.blue/)) або використання вбудованого локального кешу.

## Швидкий запуск

### 1. Клонування репозиторію
```bash
git clone [https://github.com/AmeliaArakielian/python-oop-project.git](https://github.com/AmeliaArakielian/python-oop-project.git)
cd python-oop-project