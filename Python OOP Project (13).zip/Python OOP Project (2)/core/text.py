from abc import ABC, abstractmethod
from typing import List, Optional
from core.characters import GameCharacter

class TextComponent(ABC):
    def __init__(self, name: str, uid: str = ""):
        self.name = name
        self.uid = uid or name.lower().replace(" ", "_")
        self.parent: Optional['ContainerComponent'] = None

    @abstractmethod
    def render(self, show_id: bool = False) -> str:
        pass


class LeafComponent(TextComponent):
    def __init__(self, name: str, content: str, uid: str = ""):
        super().__init__(name, uid)
        self.content = content

    def render(self, show_id: bool = False) -> str:
        id_str = f" [id: {self.uid}]" if show_id else ""
        return f"  - {self.name}: {self.content}{id_str}"


class ContainerComponent(TextComponent):
    def __init__(self, name: str, uid: str = ""):
        super().__init__(name, uid)
        self.children: List[TextComponent] = []

    def add_child(self, component: TextComponent):
        component.parent = self
        self.children.append(component)

    def render(self, show_id: bool = False) -> str:
        id_str = f" [id: {self.uid}]" if show_id else ""
        res = [f"### {self.name}{id_str}"]
        for child in self.children:
            res.append(child.render(show_id))
        return "\n".join(res)


def create_character_document(character: GameCharacter) -> ContainerComponent:
    """Використовуючи систему структурованого тексту, будує деревоподібне представлення персонажа."""
    doc = ContainerComponent(f"Персонаж: {character.name}", character.uid)
    
    info = ContainerComponent("Характеристики")
    info.add_child(LeafComponent("Титул", character.title))
    info.add_child(LeafComponent("Опис", character.description))
    info.add_child(LeafComponent("HP", str(character.hp)))
    info.add_child(LeafComponent("Атака", str(character.attack)))
    doc.add_child(info)

    abilities = ContainerComponent("Здібності")
    for ab in character.abilities:
        abilities.add_child(LeafComponent(ab.name, ab.description))
    doc.add_child(abilities)

    equipment = ContainerComponent("Екіпірування (Зброя)")
    if character.items:
        for it in character.items:
            equipment.add_child(LeafComponent(it.name, f"Стати: {it.stats}"))
    else:
        equipment.add_child(LeafComponent("Предмети", "Відсутні"))
    doc.add_child(equipment)

    return doc