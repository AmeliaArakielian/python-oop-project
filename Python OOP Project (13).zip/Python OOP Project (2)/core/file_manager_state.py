from abc import ABC, abstractmethod
import os

class ApplicationState(ABC):
    """Абстрактний стан для патерну State (режими роботи програми)."""
    @abstractmethod
    def handle_input(self, context, cmd: str, args: list) -> str:
        pass

    @abstractmethod
    def get_prompt(self) -> str:
        pass


class DirectoryState(ApplicationState):
    """1. Режим роботи: Директорія (переглядач файлової системи)."""
    def __init__(self, current_path: str = "."):
        self.current_path = current_path

    def handle_input(self, context, cmd: str, args: list) -> str:
        if cmd == "ls":
            try:
                items = os.listdir(self.current_path)
                return f"📁 Вміст директорії [{self.current_path}]:\n" + "\n".join(f"  - {item}" for item in items)
            except Exception as e:
                return f"Помилка читання директорії: {e}"
        
        elif cmd == "cd":
            if not args:
                return "Використання: cd <path>"
            new_path = os.path.join(self.current_path, args[0])
            if os.path.isdir(new_path):
                self.current_path = os.path.normpath(new_path)
                return f"Перейшли в: {self.current_path}"
            return f"Директорію '{args[0]}' не знайдено."
        
        elif cmd == "open":
            if not args:
                return "Використання: open <filename>"
            file_path = os.path.join(self.current_path, args[0])
            if os.path.isfile(file_path):
                # Перехід у режим перегляду файлу
                context.set_state(FileViewState(file_path, self.current_path))
                return f"Відкрито файл '{args[0]}' у режимі перегляду."
            return f"Файл '{args[0]}' не знайдено."
        
        elif cmd == "exit":
            context.exit_app = True
            return "Вихід із контексту додатка."
        
        return f"Невідома команда у режимі Директорії: {cmd}. Доступні: ls, cd <path>, open <file>, exit"

    def get_prompt(self) -> str:
        return f"[Режим: Директорія ({self.current_path})] > "


class FileViewState(ApplicationState):
    """2. Режим роботи: Перегляд файлу."""
    def __init__(self, file_path: str, return_path: str):
        self.file_path = file_path
        self.return_path = return_path
        self.content = ""
        self._load_file()

    def _load_file(self):
        try:
            with open(self.file_path, "r", encoding="utf-8", errors="ignore") as f:
                self.content = f.read()
        except Exception as e:
            self.content = f"[Помилка читання файлу: {e}]"

    def handle_input(self, context, cmd: str, args: list) -> str:
        if cmd == "read":
            return f"--- Вміст файлу ({os.path.basename(self.file_path)}) ---\n{self.content}\n-----------------------------------"
        
        elif cmd == "edit":
            # Перехід у режим редагування файлу
            context.set_state(FileEditState(self.file_path, self.content, self.return_path))
            return "Переведено в Режим редагування файлу."
        
        elif cmd == "close":
            # Користувач закрив файл -> повернення в режим директорії
            context.set_state(DirectoryState(self.return_path))
            return "Файл закрито. Повернення в режим Директорії."
        
        return f"Команди режиму перегляду: read, edit, close. Невідома команда: {cmd}"

    def get_prompt(self) -> str:
        return f"[Режим: Перегляд ({os.path.basename(self.file_path)})] > "


class FileEditState(ApplicationState):
    """3. Режим роботи: Редагування файлу."""
    def __init__(self, file_path: str, content: str, return_path: str):
        self.file_path = file_path
        self.content = content
        self.return_path = return_path

    def handle_input(self, context, cmd: str, args: list) -> str:
        if cmd == "write":
            # Додавання нового рядка тексту до буфера
            new_text = " ".join(args)
            self.content += "\n" + new_text
            return "Текст додано до буфера редагування."
        
        elif cmd == "save":
            try:
                with open(self.file_path, "w", encoding="utf-8") as f:
                    f.write(self.content)
                return "Зміни успішно збережено у файл!"
            except Exception as e:
                return f"Помилка збереження: {e}"
        
        elif cmd == "exit_edit":
            # Вихід з режиму редагування назад у режим перегляду
            context.set_state(FileViewState(self.file_path, self.return_path))
            return "Вихід з режиму редагування (повернення в перегляд)."
        
        return f"Команди редагування: write <text>, save, exit_edit. Невідома команда: {cmd}"

    def get_prompt(self) -> str:
        return f"[Режим: Редагування ({os.path.basename(self.file_path)})]* > "


class FileManagerContext:
    """Контекст для керування станами додатка."""
    def __init__(self):
        self.state = DirectoryState()
        self.exit_app = False

    def set_state(self, state: ApplicationState):
        self.state = state

    def execute(self, line: str) -> str:
        if not line.strip():
            return ""
        parts = line.strip().split(" ")
        cmd = parts[0]
        args = parts[1:]
        return self.state.handle_input(self, cmd, args)

    def get_prompt(self) -> str:
        return self.state.get_prompt()