from core.patterns import DefaultAttackStrategy, CharacterMemento, CharacterObserver
from typing import List, Dict, Optional

class GameItem:
    def __init__(self, name: str, uid: str, stats: dict):
        self.name = name
        self.uid = uid
        self.stats = stats


class GameAbility:
    def __init__(self, name: str, description: str, uid: str = ""):
        self.name = name
        self.description = description
        self.uid = uid or name.lower().replace(" ", "_")


class GameCharacter:
    def __init__(self, name: str, uid: str, title: str = "", description: str = ""):
        self._strategy = DefaultAttackStrategy()
        self._observers = []
        self._mementos = []
        self.name = name
        self.uid = uid
        self.title = title
        self.description = description
        self.items: List[GameItem] = []
        self.abilities: List[GameAbility] = []
        self.hp: int = 100
        self.attack: int = 25
    def set_strategy(self, strategy):
        self._strategy = strategy
 
    def perform_combat(self) -> str:
        return self._strategy.execute_combat(self)

    def add_observer(self, observer):
        self._observers.append(observer)
 
    def notify_observers(self, message: str):
        for obs in self._observers:
            obs.update(message)

    def save_state(self):
        memento = CharacterMemento(self.hp, self.attack)
        self._mementos.append(memento)
        self.notify_observers(f"Збережено стан персонажа {self.name} (HP: {self.hp})")

    def restore_state(self):
        if self._mementos:
            memento = self._mementos.pop()
            self.hp = memento.hp
            self.attack = memento.attack
            self.notify_observers(f"Відновлено стан персонажа {self.name} (HP: {self.hp})")


class CharacterManager:
    def __init__(self):
        self.characters: Dict[str, GameCharacter] = {}
        self.items: Dict[str, GameItem] = {}
        self.abilities: Dict[str, GameAbility] = {}

    def add_character_from_api(self, api_data: dict) -> GameCharacter:
        """Транслює інформацію із зовнішнього API на внутрішні класи персонажів."""
        name = api_data.get("name", "Unknown")
        uid = name.lower().replace(" ", "_")
        title = api_data.get("title", "")
        description = api_data.get("description", "")
        
        char = GameCharacter(name, uid, title, description)
        
        # Парсинг здібностей
        talents = api_data.get("combat-talents", []) or api_data.get("talents", [])
        for talent in talents:
            t_name = talent.get("name", "Skill")
            t_desc = talent.get("description", "")
            ability = GameAbility(t_name, t_desc)
            char.abilities.append(ability)
            self.abilities[ability.uid] = ability

        self.characters[uid] = char
        return char

    def add_weapon_from_api(self, name: str, api_data: dict) -> GameItem:
        """Додає зброю з API як ігровий предмет."""
        uid = name.lower().replace(" ", "_")
        base_atk = api_data.get("baseAttack", 40)
        item = GameItem(name, uid, {"baseAttack": base_atk})
        self.items[uid] = item
        return item

    def assign_item_to_character(self, char_id: str, item_id: str) -> bool:
        """Екіпірує предмет на віртуального персонажа."""
        char = self.characters.get(char_id)
        item = self.items.get(item_id)
        if char and item:
            char.items.append(item)
            char.attack += item.stats.get("baseAttack", 15)
            return True
        return False