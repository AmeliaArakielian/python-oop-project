from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional
import urllib.request
import json
from infra.image_cache import ImageCacheManager


@dataclass
class CharacterViewModel:
    id: str
    name: str
    title: str
    vision: str
    weapon: str
    rarity: int
    nation: str
    description: str
    skills: List[str] = field(default_factory=list)
    local_portrait_path: str = ""

    def format_card(self) -> str:
        stars = "★" * self.rarity
        skills_str = ", ".join(self.skills) if self.skills else "Немає даних"
        return (
            f"[{self.name}] ({stars}) — {self.title}\n"
            f"  Елемент: {self.vision} | Зброя: {self.weapon} | Регіон: {self.nation}\n"
            f"  Локальний портрет (кеш): {self.local_portrait_path}\n"
            f"  Навички: {skills_str}\n"
            f"  Опис: {self.description}"
        )


class GenshinApiClientStub:
    """
    Інфраструктурний клієнт для отримання даних з https://genshin.jmp.blue/
    Містить резервний словник (mock) на випадок відсутності інтернету.
    """
    BASE_URL = "https://genshin.jmp.blue"

    MOCK_DATA: Dict[str, Dict[str, Any]] = {
        "diluc": {
            "name": "Diluc",
            "title": "The Dark Side of Dawn",
            "vision": "Pyro",
            "weapon": "Claymore",
            "rarity": 5,
            "nation": "Mondstadt",
            "description": "The tycoon of a winery empire in Mondstadt.",
            "skillTalents": [{"name": "Tempered Sword"}, {"name": "Dawn"}]
        },
        "ganyu": {
            "name": "Ganyu",
            "title": "Plenilune Gaze",
            "vision": "Cryo",
            "weapon": "Bow",
            "rarity": 5,
            "nation": "Liyue",
            "description": "The secretary at Yuehai Pavilion.",
            "skillTalents": [{"name": "Liutian Archery"}, {"name": "Celestial Shower"}]
        },
        "zhongli": {
            "name": "Zhongli",
            "title": "Vago Mundo",
            "vision": "Geo",
            "weapon": "Polearm",
            "rarity": 5,
            "nation": "Liyue",
            "description": "A mysterious expert contracted by the Wangsheng Funeral Parlor.",
            "skillTalents": [{"name": "Rain of Stone"}, {"name": "Planet Befall"}]
        }
    }

    def fetch_character_list(self) -> List[str]:
        try:
            req = urllib.request.Request(
                f"{self.BASE_URL}/characters",
                headers={"User-Agent": "Python-OOP-Project"}
            )
            with urllib.request.urlopen(req, timeout=3) as response:
                data = json.loads(response.read().decode("utf-8"))
                if isinstance(data, list):
                    return data
        except Exception:
            pass
        return list(self.MOCK_DATA.keys())

    def fetch_character_json(self, char_id: str) -> Optional[Dict[str, Any]]:
        clean_id = char_id.strip().lower()
        try:
            req = urllib.request.Request(
                f"{self.BASE_URL}/characters/{clean_id}",
                headers={"User-Agent": "Python-OOP-Project"}
            )
            with urllib.request.urlopen(req, timeout=3) as response:
                return json.loads(response.read().decode("utf-8"))
        except Exception:
            return self.MOCK_DATA.get(clean_id)


class GenshinJsonParser:
    @staticmethod
    def parse_character(char_id: str, raw_data: Dict[str, Any]) -> CharacterViewModel:
        raw_skills = raw_data.get("skillTalents", [])
        skill_names = [
            skill.get("name", "Невідома навичка")
            for skill in raw_skills
            if isinstance(skill, dict) and "name" in skill
        ]

        return CharacterViewModel(
            id=char_id.lower(),
            name=raw_data.get("name", char_id.capitalize()),
            title=raw_data.get("title", "Мандрівник"),
            vision=raw_data.get("vision", "Невідомо"),
            weapon=raw_data.get("weapon", "Невідомо"),
            rarity=int(raw_data.get("rarity", 4)),
            nation=raw_data.get("nation", "Невідомо"),
            description=raw_data.get("description", "Опис відсутній."),
            skills=skill_names
        )


class CatalogService:
    def __init__(self, api_client=None):
        self._api = api_client or GenshinApiClientStub()
        self._parser = GenshinJsonParser()
        self._cache: Dict[str, CharacterViewModel] = {}
        self._image_cache = ImageCacheManager()

    def get_available_ids(self) -> List[str]:
        return self._api.fetch_character_list()

    def get_character_model(self, char_id: str) -> Optional[CharacterViewModel]:
        clean_id = char_id.strip().lower()
        if clean_id in self._cache:
            return self._cache[clean_id]

        raw_json = self._api.fetch_character_json(clean_id)
        if not raw_json:
            return None

        base_url = f"https://genshin.jmp.blue/characters/{clean_id}"
        portrait_path = self._image_cache.cache_portrait(clean_id, base_url)

        model = self._parser.parse_character(clean_id, raw_json)
        model.local_portrait_path = portrait_path
        self._cache[clean_id] = model
        return model