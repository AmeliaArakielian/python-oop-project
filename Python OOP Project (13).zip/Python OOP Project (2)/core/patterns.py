from abc import ABC, abstractmethod

# 1. STRATEGY PATTERN (Стратегія для атак / дій)
class CombatStrategy(ABC):
    @abstractmethod
    def execute_combat(self, character) -> str:
        pass

class DefaultAttackStrategy(CombatStrategy):
    def execute_combat(self, character) -> str:
        return f"{character.name} виконує стандартну атаку з уроном {character.attack}."

class HeavyAttackStrategy(CombatStrategy):
    def execute_combat(self, character) -> str:
        return f"{character.name} виконує потужну важку атаку (урон: {character.attack * 2})!"


# 2. MEMENTO PATTERN (Збереження стану персонажа)
class CharacterMemento:
    def __init__(self, hp: int, attack: int):
        self._hp = hp
        self._attack = attack

    @property
    def hp(self) -> int:
        return self._hp

    @property
    def attack(self) -> int:
        return self._attack


# 3. OBSERVER PATTERN (Сповіщення про зміни станів)
class CharacterObserver:
    def update(self, message: str):
        print(f"[ЛОГ СПОСТЕРІГАЧА]: {message}")


# 4. COMMAND PATTERN (Інкапсуляція дій)
class GameCommand(ABC):
    @abstractmethod
    def execute(self) -> str:
        pass