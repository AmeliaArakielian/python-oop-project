"""
Module containing specialized character classes derived from Character.
"""

from character import Character


class Soldier(Character):
    """Soldier/Warrior character class with balanced stats."""

    def __init__(self, name: str) -> None:
        super().__init__(name=name, health=120, armor=15, attack_power=22)


class Mage(Character):
    """Mage character class with high magic attack and low armor."""

    def __init__(self, name: str) -> None:
        super().__init__(name=name, health=85, armor=6, attack_power=32)


class Healer(Character):
    """Healer character class focused on support."""

    def __init__(self, name: str) -> None:
        super().__init__(name=name, health=100, armor=10, attack_power=15)