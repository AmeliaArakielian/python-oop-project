"""
Main execution script demonstrating both Text Abstraction and Game System.
"""

from text_elements import Text, Heading, Paragraph, Image, Link
from characters import Soldier, Mage, Healer
from equipment import Weapon, Armor, ShieldBash, Fireball


def demonstrate_text_system():
    print("=" * 60)
    print("PART 1: TEXT ABSTRACTION SYSTEM DEMO")
    print("=" * 60)

    # Article Creation
    article = Text(title="Modern Software Engineering")

    # Adding elements
    h1 = Heading(text="1. Introduction to OOP", level=1)
    p1 = Paragraph(text="Object-oriented programming helps structure complex systems effectively.")
    h2 = Heading(text="1.1 Core Principles", level=2)
    p2 = Paragraph(text="Encapsulation, Inheritance, and Polymorphism form the core pillars.")
    img = Image(alt_text="Architecture Diagram", url="https://example.com/diagram.png")
    link = Link(label="Official Docs", url="https://docs.python.org/3/")
    h3 = Heading(text="2. Conclusion", level=1)

    article.add_element(h1)
    article.add_element(p1)
    article.add_element(h2)
    article.add_element(p2)
    article.add_element(img)
    article.add_element(h3)
    article.add_element(link)

    # Output Table of Contents
    print("\n" + article.get_table_of_contents())

    # Output Full Document Content
    print("\n--- FULL RENDERED ARTICLE ---")
    print(article)


def demonstrate_game_system():
    print("\n" + "=" * 60)
    print("PART 2: GAME SYSTEM DEMO")
    print("=" * 60)

    # Instantiating Characters
    romeo = Soldier(name="Romeo")
    merlin = Mage(name="Merlin")
    healer = Healer(name="Elena")

    # Equipping Skills
    romeo.special_ability = ShieldBash()
    merlin.special_ability = Fireball()

    print("\n--- INITIAL STATUS ---")
    print(romeo.get_status())
    print(merlin.get_status())
    print(healer.get_status())

    print("\n--- COMBAT & INTERACTION SIMULATION ---")
    
    # Basic Attack
    print(romeo.attack(merlin))

    # Equipping Items
    sword = Weapon(name="Excalibur", bonus_attack=12)
    robe = Armor(name="Mystic Robe", bonus_armor=6, bonus_health=15)

    print(romeo.equip_item(sword))
    print(merlin.equip_item(robe))

    # Special Abilities & Equipment usage
    print(merlin.use_ability(romeo))
    print(romeo.use_equipment_ability(merlin))

    # Healing
    print(healer.heal(20))

    print("\n--- FINAL STATUS ---")
    print(romeo.get_status())
    print(merlin.get_status())
    print(healer.get_status())


if __name__ == "__main__":
    demonstrate_text_system()
    demonstrate_game_system()