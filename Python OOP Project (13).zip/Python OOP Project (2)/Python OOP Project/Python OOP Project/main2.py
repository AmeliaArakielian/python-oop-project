import sys
import shlex
from abc import ABC, abstractmethod
from typing import List, Dict, Optional, Any

# ==========================================
# ЧАСТИНА 1: СИСТЕМА СТРУКТУРОВАНОГО ТЕКСТУ
# ==========================================

class TextComponent(ABC):
    """Абстрактний базовий клас для елементів тексту (Абстракція)."""
    def __init__(self, name: str, uid: str = ""):
        self.name = name
        self.uid = uid or name.lower().replace(" ", "_")
        self.parent: Optional['ContainerComponent'] = None

    @abstractmethod
    def render(self, show_id: bool = False) -> str:
        pass


class LeafComponent(TextComponent):
    """Кінцевий елемент тексту (абзац, заголовок тощо)."""
    def __init__(self, name: str, content: str, uid: str = ""):
        super().__init__(name, uid)
        self.content = content

    def render(self, show_id: bool = False) -> str:
        id_str = f" [id: {self.uid}]" if show_id else ""
        return f"{self.name}: {self.content}{id_str}\n"


class ContainerComponent(TextComponent):
    """Контейнер для інших елементів (розділ, документ)."""
    def __init__(self, name: str, uid: str = ""):
        super().__init__(name, uid)
        self.children: List[TextComponent] = []

    def add_child(self, component: TextComponent):
        component.parent = self
        self.children.append(component)

    def remove_child(self, name_or_id: str) -> bool:
        for i, child in enumerate(self.children):
            if child.name == name_or_id or child.uid == name_or_id:
                child.parent = None
                self.children.pop(i)
                return True
        return False

    def render(self, show_id: bool = False) -> str:
        id_str = f" [id: {self.uid}]" if show_id else ""
        res = [f"### {self.name}{id_str}"]
        for child in self.children:
            res.append(child.render(show_id))
        return "\n".join(res)


class TextDocumentManager:
    """Менеджер навігації та маніпуляцій структурованим текстом."""
    def __init__(self):
        self.root = ContainerComponent("root", "root")
        self.current: ContainerComponent = self.root

    def get_pwd(self) -> str:
        path = []
        curr: Optional[TextComponent] = self.current
        while curr and curr != self.root:
            path.insert(0, curr.name)
            curr = curr.parent
        return "/" + "/".join(path)

    def cd(self, path_or_id: str) -> bool:
        if path_or_id == "/":
            self.current = self.root
            return True
        if path_or_id == "..":
            if self.current.parent:
                self.current = self.current.parent
                return True
            return False
        
        # Пошук серед дочірніх елементів поточного контейнера
        for child in self.current.children:
            if isinstance(child, ContainerComponent) and (child.name == path_or_id or child.uid == path_or_id):
                self.current = child
                return True
        return False

    def up(self) -> bool:
        if self.current.parent:
            self.current = self.current.parent
            return True
        return False

    def rm(self, name_or_id: Optional[str] = None) -> bool:
        if name_or_id:
            return self.current.remove_child(name_or_id)
        else:
            if self.current == self.root:
                return False
            parent = self.current.parent
            if parent:
                parent.remove_child(self.current.name)
                self.current = parent
                return True
        return False


# ==========================================
# ЧАСТИНА 2: СИСТЕМА ПЕРСОНАЖІВ ТА ГРИ
# ==========================================

class GameItem:
    def __init__(self, name: str, uid: str, stats: dict):
        self.name = name
        self.uid = uid
        self.stats = stats


class GameAbility:
    def __init__(self, name: str, uid: str, power: int):
        self.name = name
        self.uid = uid
        self.power = power


class GameCharacter:
    def __init__(self, name: str, uid: str):
        self.name = name
        self.uid = uid
        self.items: List[GameItem] = []
        self.abilities: List[GameAbility] = []
        self.hp: int = 100


class CharacterManager:
    """Менеджер для управління персонажами, предметами та здібностями."""
    def __init__(self):
        self.characters: Dict[str, GameCharacter] = {}
        self.items: Dict[str, GameItem] = {}
        self.abilities: Dict[str, GameAbility] = {}

    def add_character(self, name: str, uid: str):
        self.characters[uid] = GameCharacter(name, uid)

    def add_item(self, name: str, uid: str, stats: dict):
        self.items[uid] = GameItem(name, uid, stats)

    def add_ability(self, name: str, uid: str, power: int):
        self.abilities[uid] = GameAbility(name, uid, power)

    def assign_to_char(self, char_id: str, obj_id: str, obj_type: str):
        char = self.characters.get(char_id)
        if not char:
            print(f"Персонажа з ID/іменем '{char_id}' не знайдено.")
            return
        if obj_type == "item":
            item = self.items.get(obj_id)
            if item:
                char.items.append(item)
                print(f"Предмет '{item.name}' успішно додано до персонажа '{char.name}'.")
            else:
                print(f"Предмет '{obj_id}' не знайдено.")
        elif obj_type == "ability":
            ability = self.abilities.get(obj_id)
            if ability:
                char.abilities.append(ability)
                print(f"Здібність '{ability.name}' успішно додано до персонажа '{char.name}'.")
            else:
                print(f"Здібність '{obj_id}' не знайдено.")

    def execute_action(self, action: str, actor_id: str, target_id: str, ability_id: Optional[str] = None):
        actor = self.characters.get(actor_id)
        target = self.characters.get(target_id)
        if not actor or not target:
            print("Помилка: Актор або ціль не знайдені.")
            return
        
        if action == "attack":
            dmg = 15
            if ability_id and ability_id in self.abilities:
                dmg = self.abilities[ability_id].power
            target.hp = max(0, target.hp - dmg)
            print(f"⚔️ [{actor.name}] атакує [{target.name}], завдаючи {dmg} шкоди! HP цілі: {target.hp}.")
        elif action == "heal":
            heal_pts = 20
            target.hp += heal_pts
            print(f"💚 [{actor.name}] лікує [{target.name}] на {heal_pts} HP. Здоров'я цілі: {target.hp}.")
        else:
            print(f"Невідома дія: {action}")


# ==========================================
# ЧАСТИНА 3: УНІФІКОВАНИЙ КОМАНДНИЙ ІНТЕРФЕЙС (CLI)
# ==========================================

class CLIInterpreter:
    """Інтерпретатор команд для керування обома системами."""
    def __init__(self, mode: Optional[str] = None):
        self.text_mgr = TextDocumentManager()
        self.char_mgr = CharacterManager()
        self.mode = mode

    def select_mode_interactively(self):
        print("\n=== Оберіть режим роботи командного інтерфейсу ===")
        print("1. text  - Режим управління структурованим текстом")
        print("2. chars - Режим управління персонажами та грою")
        choice = input("Введіть назву або номер режиму (text/chars): ").strip().lower()
        if choice in ["1", "text", "--text"]:
            self.mode = "text"
        elif choice in ["2", "chars", "--chars"]:
            self.mode = "chars"
        else:
            print("Невірний вибір. За замовчуванням активовано режим 'text'.")
            self.mode = "text"

    def run(self):
        if not self.mode:
            self.select_mode_interactively()

        print(f"\n--- Режим інтерпретатора: [{self.mode.upper()}] ---")
        print("Введіть 'exit' або 'quit' для виходу з програми.\n")

        while True:
            try:
                line = input("> ").strip()
                if not line:
                    continue
                if line in ["exit", "quit"]:
                    print("Вихід з програми. До побачення!")
                    break
                
                parts = shlex.split(line)
                cmd = parts[0]
                args = parts[1:]

                if self.mode == "text":
                    self.handle_text_command(cmd, args)
                elif self.mode == "chars":
                    self.handle_chars_command(cmd, args)

            except Exception as e:
                print(f"Сталася помилка при виконанні команди: {e}")

    # Обробка команд для підсистеми Text
    def handle_text_command(self, cmd: str, args: List[str]):
        if cmd == "pwd":
            print(self.text_mgr.get_pwd())
        elif cmd == "print":
            whole = "--whole" in args
            show_id = "--id" in args
            if whole:
                print(self.text_mgr.root.render(show_id))
            else:
                print(self.text_mgr.current.render(show_id))
        elif cmd == "up":
            if not self.text_mgr.up():
                print("Вже на кореневому рівні документа.")
        elif cmd == "cd":
            if not args:
                print("Використання: cd <path> або cd --id <container_id>")
                return
            target = args[1] if args[0] == "--id" and len(args) > 1 else args[0]
            if not self.text_mgr.cd(target):
                print(f"Помилка: шлях або контейнер '{target}' не знайдено.")
        elif cmd == "add":
            if len(args) < 2:
                print("Використання: add <container|leaf> <name>")
                return
            elem_type = args[0]
            name = args[1]
            if elem_type == "container":
                uid = input("Введіть унікальний ID контейнера (або Enter для авто): ").strip()
                new_c = ContainerComponent(name, uid)
                self.text_mgr.current.add_child(new_c)
                print(f"Контейнер '{name}' успішно додано.")
            elif elem_type == "leaf":
                content = input("Введіть текстовий вміст елемента: ")
                uid = input("Введіть унікальний ID (або Enter для авто): ").strip()
                new_l = LeafComponent(name, content, uid)
                self.text_mgr.current.add_child(new_l)
                print(f"Елемент '{name}' успішно додано.")
            else:
                print("Невідомий тип. Використовуйте 'container' або 'leaf'.")
        elif cmd == "rm":
            name_or_id = args[0] if args else None
            if not name_or_id:
                confirm = input(f"Видалити поточний контейнер '{self.text_mgr.current.name}' та перейти вище? (y/n): ")
                if confirm.lower() != 'y':
                    return
            success = self.text_mgr.rm(name_or_id)
            if success:
                print("Елемент успішно видалено.")
            else:
                print("Не вдалося видалити елемент.")
        else:
            print(f"Невідома команда тексту: '{cmd}'. Доступні: pwd, print, cd, up, add, rm.")

    # Обробка команд для підсистеми Characters
    def handle_chars_command(self, cmd: str, args: List[str]):
        if cmd == "create":
            if not args:
                print("Використання: create <char|item|ability>")
                return
            obj_type = args[0]
            name = input("Введіть назву об'єкта: ").strip()
            uid = input("Введіть унікальний ID: ").strip()
            if obj_type == "char":
                self.char_mgr.add_character(name, uid)
                print(f"Персонажа '{name}' створено.")
            elif obj_type == "item":
                bonus = int(input("Введіть бонус предмета (число): ") or 0)
                self.char_mgr.add_item(name, uid, {"bonus": bonus})
                print(f"Предмет '{name}' створено.")
            elif obj_type == "ability":
                power = int(input("Введіть силу здібності (число): ") or 10)
                self.char_mgr.add_ability(name, uid, power)
                print(f"Здібність '{name}' створено.")
            else:
                print("Невідомий тип для створення. Використовуйте char, item або ability.")
        elif cmd == "add":
            # Приклад: add --char_id hero1 --id sword1
            char_id, obj_id = None, None
            i = 0
            while i < len(args):
                if args[i] == "--char_id" and i + 1 < len(args):
                    char_id = args[i+1]
                    i += 2
                elif args[i] == "--id" and i + 1 < len(args):
                    obj_id = args[i+1]
                    i += 2
                else:
                    i += 1
            if not char_id or not obj_id:
                print("Використання: add --char_id <id/name> --id <id/name>")
                return
            obj_type = "item" if obj_id in self.char_mgr.items else "ability"
            self.char_mgr.assign_to_char(char_id, obj_id, obj_type)
        elif cmd == "act":
            # Приклад: act attack hero1 target1 --id fireball
            if len(args) < 3:
                print("Використання: act <attack|heal|ability> <actor> <target> [--id <id>]")
                return
            action = args[0]
            actor = args[1]
            target = args[2]
            ability_id = None
            if "--id" in args:
                idx = args.index("--id")
                if idx + 1 < len(args):
                    ability_id = args[idx+1]
            self.char_mgr.execute_action(action, actor, target, ability_id)
        elif cmd == "ls":
            if not args:
                print("=== Персонажі ===")
                for uid, c in self.char_mgr.characters.items():
                    print(f"- {c.name} (ID: {uid}, HP: {c.hp}, Предметів: {len(c.items)}, Здібностей: {len(c.abilities)})")
                print("=== Предмети ===")
                for uid, it in self.char_mgr.items.items():
                    print(f"- {it.name} (ID: {uid})")
                print("=== Здібності ===")
                for uid, ab in self.char_mgr.abilities.items():
                    print(f"- {ab.name} (ID: {uid}, Сила: {ab.power})")
            else:
                target_type = args[0]
                target_id = args[1] if len(args) > 1 and args[1] != "--id" else (args[2] if len(args) > 2 else None)
                if target_type == "char" and target_id in self.char_mgr.characters:
                    c = self.char_mgr.characters[target_id]
                    print(f"Персонаж {c.name} [ID: {c.uid}]: HP={c.hp}")
                    print(f"  Предмети: {[i.name for i in c.items]}")
                    print(f"  Здібності: {[a.name for a in c.abilities]}")
                elif target_type == "item" and target_id in self.char_mgr.items:
                    it = self.char_mgr.items[target_id]
                    print(f"Предмет {it.name} [ID: {it.uid}]: stats={it.stats}")
                elif target_type == "ability" and target_id in self.char_mgr.abilities:
                    ab = self.char_mgr.abilities[target_id]
                    print(f"Здібність {ab.name} [ID: {ab.uid}]: power={ab.power}")
                else:
                    print("Об'єкт не знайдено або не вказано коректний ID.")
        else:
            print(f"Невідома команда персонажів: '{cmd}'. Доступні: create, add, act, ls.")


# ==========================================
# ТОЧКА ВХОДУ ДОДАТКУ
# ==========================================
if __name__ == "__main__":
    selected_mode = None
    if "--text" in sys.argv:
        selected_mode = "text"
    elif "--chars" in sys.argv:
        selected_mode = "chars"

    interpreter = CLIInterpreter(mode=selected_mode)
    interpreter.run()