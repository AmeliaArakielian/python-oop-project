"""
Module providing text abstraction components and document container.
"""

from abc import ABC, abstractmethod
from typing import List


class TextElement(ABC):
    """Abstract base class for printable document elements."""

    @abstractmethod
    def render(self) -> str:
        """Render the element to string representation."""
        pass


class Heading(TextElement):
    """Heading element with specified hierarchy level (1-6)."""

    def __init__(self, text: str, level: int = 1) -> None:
        if not 1 <= level <= 6:
            raise ValueError("Level must be between 1 and 6.")
        self.text = text
        self.level = level

    def render(self) -> str:
        return f"{'#' * self.level} {self.text}"


class Paragraph(TextElement):
    """Paragraph element for plain text blocks."""

    def __init__(self, text: str) -> None:
        self.text = text

    def render(self) -> str:
        return self.text


class Image(TextElement):
    """Image element with alt text and source URL."""

    def __init__(self, alt_text: str, url: str) -> None:
        self.alt_text = alt_text
        self.url = url

    def render(self) -> str:
        return f"![{self.alt_text}]({self.url})"


class Link(TextElement):
    """Hyperlink element."""

    def __init__(self, label: str, url: str) -> None:
        self.label = label
        self.url = url

    def render(self) -> str:
        return f"[{self.label}]({self.url})"


class Text:
    """Document container managing elements and generating Table of Contents."""

    def __init__(self, title: str) -> None:
        self.title = title
        self._elements: List[TextElement] = []

    def add_element(self, element: TextElement, index: int = -1) -> None:
        """Add an element to document."""
        if index == -1 or index >= len(self._elements):
            self._elements.append(element)
        else:
            self._elements.insert(index, element)

    def remove_element(self, index: int) -> TextElement:
        """Remove element by index."""
        return self._elements.pop(index)

    def swap_elements(self, index1: int, index2: int) -> None:
        """Swap positions of two elements."""
        self._elements[index1], self._elements[index2] = (
            self._elements[index2],
            self._elements[index1],
        )

    def get_table_of_contents(self) -> str:
        """Generate Table of Contents with indentation based on heading levels."""
        lines = ["--- Table of Contents ---"]
        for element in self._elements:
            if isinstance(element, Heading):
                indent = "  " * (element.level - 1)
                lines.append(f"{indent}- {element.text}")
        return "\n".join(lines)

    def __str__(self) -> str:
        """Render complete document into formatted text."""
        result = [f"# {self.title}\n"]
        result.extend(elem.render() for elem in self._elements)
        return "\n\n".join(result)