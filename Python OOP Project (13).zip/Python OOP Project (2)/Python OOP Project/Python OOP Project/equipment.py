"""
Module defining items, equipment, and special abilities.
"""

from abc import ABC, abstractmethod


class Item:
    """Base item class for stat boosters."""

    def __init__(
        self,
        name: str,
        bonus_health: int = 0,
        bonus_armor: int = 0,
        bonus_attack: int = 0,
    ) -> None:
        self.name = name
        self.bonus_health = bonus_health
        self.bonus_armor = bonus_armor
        self.bonus_attack = bonus_attack


class Weapon(Item):
    """Weapon item boosting attack stats."""

    def __init__(self, name: str, bonus_attack: int) -> None:
        super().__init__(name=name, bonus_attack=bonus_attack)


class Armor(Item):
    """Armor item boosting defense and health stats."""

    def __init__(self, name: str, bonus_armor: int, bonus_health: int = 0) -> None:
        super().__init__(name=name, bonus_armor=bonus_armor, bonus_health=bonus_health)


class Ability(ABC):
    """Abstract base class for character abilities."""

    def __init__(self, name: str) -> None:
        self.name = name

    @abstractmethod
    def execute(self, caster, target) -> str:
        """Execute unique skill logic."""
        pass


class ShieldBash(Ability):
    """Warrior ability dealing heavy physical damage and boosting armor."""

    def __init__(self) -> None:
        super().__init__(name="Shield Bash")

    def execute(self, caster, target) -> str:
        damage = caster.attack_power + 15
        caster.armor += 5
        dealt = target.take_damage(damage)
        return f"🛡️ {caster.name} uses {self.name} on {target.name}! Deals {dealt} damage and gains +5 armor."


class Fireball(Ability):
    """Mage ability bypassing target's armor."""

    def __init__(self) -> None:
        super().__init__(name="Fireball")

    def execute(self, caster, target) -> str:
        raw_damage = caster.attack_power + 20
        effective_armor = target.armor // 2
        dealt = max(1, raw_damage - effective_armor)
        target.health = max(0, target.health - dealt)
        return f"🔥 {caster.name} casts {self.name} at {target.name}! Pierces armor, dealing {dealt} magic damage."