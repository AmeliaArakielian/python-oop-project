"""
Module defining the base Character class for the game system.
"""

from typing import List, Optional


class Character:
    """Base class for all game characters holding core stats and mechanics."""

    def __init__(self, name: str, health: int, armor: int, attack_power: int) -> None:
        self.name: str = name
        self.max_health: int = health
        self.health: int = health
        self.armor: int = armor
        self.attack_power: int = attack_power
        self.equipped_items: List = []
        self.special_ability: Optional[object] = None

    @property
    def is_alive(self) -> bool:
        """Check if character is alive."""
        return self.health > 0

    def take_damage(self, amount: int) -> int:
        """Calculate effective damage after applying armor mitigation."""
        effective_damage = max(1, amount - self.armor)
        self.health = max(0, self.health - effective_damage)
        return effective_damage

    def attack(self, target: "Character") -> str:
        """Perform a basic attack on a target character."""
        if not self.is_alive:
            return f"{self.name} cannot attack because they are defeated."
        
        damage_dealt = target.take_damage(self.attack_power)
        return f"⚔️ {self.name} attacks {target.name} for {damage_dealt} damage! ({target.name} HP: {target.health}/{target.max_health})"

    def heal(self, amount: int) -> str:
        """Restore health points up to maximum health."""
        if not self.is_alive:
            return f"{self.name} cannot be healed."
        
        previous_hp = self.health
        self.health = min(self.max_health, self.health + amount)
        restored = self.health - previous_hp
        return f"💚 {self.name} heals for {restored} HP! (Current HP: {self.health}/{self.max_health})"

    def equip_item(self, item) -> str:
        """Equip an item and add its bonus stats."""
        self.equipped_items.append(item)
        self.max_health += item.bonus_health
        self.health += item.bonus_health
        self.armor += item.bonus_armor
        self.attack_power += item.bonus_attack
        return f"🎒 {self.name} equipped [{item.name}] (+{item.bonus_attack} ATK, +{item.bonus_armor} ARM, +{item.bonus_health} HP)."

    def use_ability(self, target: "Character") -> str:
        """Trigger unique class ability."""
        if not self.special_ability:
            return f"{self.name} has no special ability!"
        return self.special_ability.execute(self, target)

    def use_equipment_ability(self, target: "Character") -> str:
        """Use ability from equipped items if present."""
        return self.use_ability(target)

    def get_status(self) -> str:
        """Return formatted overview of character's stats."""
        status = "ALIVE" if self.is_alive else "DEFEATED"
        return f"[{self.name}] HP: {self.health}/{self.max_health} | Armor: {self.armor} | Attack: {self.attack_power} | Status: {status}"