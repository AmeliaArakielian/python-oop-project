import tkinter as tk
from tkinter import ttk, messagebox
import os
from core.catalog_service import CatalogService, CharacterViewModel


class CharacterCatalogApp:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("Каталог персонажів Genshin Impact (Практична №16 - GUI)")
        self.root.geometry("850x600")
        
        # Ініціалізуємо сервіс бізнес-логіки 
        self.catalog_service = CatalogService()
        
        # Створюємо макет інтерфейсу
        self._create_widgets()
        self._load_character_list()

    def _create_widgets(self):
        # Головний контейнер (розбитий на дві частини: зліва список, справа картка)
        main_pane = ttk.PanedWindow(self.root, orient=tk.HORIZONTAL)
        main_pane.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        # --- Ліва панель: Список ID персонажів ---
        left_frame = ttk.Frame(main_pane)
        main_pane.add(left_frame, weight=1)

        lbl_list = ttk.Label(left_frame, text="Доступні персонажі (API):", font=("Arial", 11, "bold"))
        lbl_list.pack(anchor=tk.W, pady=5)

        # Список із прокруткою (Scrollable Listbox)
        list_scroll = ttk.Scrollbar(left_frame)
        list_scroll.pack(side=tk.RIGHT, fill=tk.Y)

        self.char_listbox = tk.Listbox(left_frame, yscrollcommand=list_scroll.set, font=("Arial", 10), height=25)
        self.char_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        list_scroll.config(command=self.char_listbox.yview)

        # Подія вибору персонажа зі списку
        self.char_listbox.bind("<<ListboxSelect>>", self._on_character_select)

        # Кнопка оновлення списку
        btn_refresh = ttk.Button(left_frame, text="Оновити список з API", command=self._load_character_list)
        btn_refresh.pack(fill=tk.X, pady=5)

        # --- Права панель: Деталі персонажа (Картка) ---
        right_frame = ttk.Frame(main_pane)
        main_pane.add(right_frame, weight=2)

        lbl_details = ttk.Label(right_frame, text="Картка персонажа:", font=("Arial", 11, "bold"))
        lbl_details.pack(anchor=tk.W, pady=5)

        # Текстове поле для виводу інформації про персонажа
        self.info_text = tk.Text(right_frame, wrap=tk.WORD, font=("Arial", 11), width=45, height=20)
        self.info_text.pack(fill=tk.BOTH, expand=True, pady=5)
        self.info_text.config(state=tk.DISABLED)

        # Мітка для відображення статусу кешу портрета
        self.status_lbl = ttk.Label(right_frame, text="Статус кешу портрета: очікування...", font=("Arial", 9, "italic"), foreground="gray")
        self.status_lbl.pack(anchor=tk.W, pady=5)

    def _load_character_list(self):
        self.char_listbox.delete(0, tk.END)
        try:
            char_ids = self.catalog_service.get_available_ids()
            for cid in char_ids:
                self.char_listbox.insert(tk.END, cid)
        except Exception as e:
            messagebox.showerror("Помилка мережі", f"Не вдалося завантажити список з API: {e}")

    def _on_character_select(self, event):
        selection = self.char_listbox.curselection()
        if not selection:
            return
        index = selection[0]
        char_id = self.char_listbox.get(index)

        # Отримуємо розпарсену модель з бізнес-логіки та кешу
        model = self.catalog_service.get_character_model(char_id)
        if model:
            self._display_character(model)

    def _display_character(self, model: CharacterViewModel):
        # Форматуємо текст картки
        card_content = (
            f"Ім'я: {model.name}\n"
            f"Титул: {model.title}\n"
            f"Рідкість: {'★' * model.rarity} ({model.rarity} зірок)\n"
            f"Елемент (Vision): {model.vision}\n"
            f"Зброя: {model.weapon}\n"
            f"Регіон (Nation): {model.nation}\n\n"
            f"Навички:\n" + "".join([f"  • {s}\n" for s in model.skills]) + "\n"
            f"Опис:\n{model.description}\n"
        )

        # Виводимо у текстове поле
        self.info_text.config(state=tk.NORMAL)
        self.info_text.delete("1.0", tk.END)
        self.info_text.insert(tk.END, card_content)
        self.info_text.config(state=tk.DISABLED)

        # Перевіряємо локальний кеш портрета 
        if os.path.exists(model.local_portrait_path):
            file_size = os.path.getsize(model.local_portrait_path)
            self.status_lbl.config(
                text=f"[Кеш активний] Портрет збережено: {model.local_portrait_path} ({file_size} байт)",
                foreground="green"
            )
        else:
            self.status_lbl.config(text="Портрет відсутній у кеші.", foreground="red")


if __name__ == "__main__":
    root = tk.Tk()
    app = CharacterCatalogApp(root)
    root.mainloop()