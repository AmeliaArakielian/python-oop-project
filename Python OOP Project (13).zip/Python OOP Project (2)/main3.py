import sys
from cli.commands import CommandInterpreter
from cli.presenter import CLIPresenter

if __name__ == "__main__":
    mode = None
    if "--text" in sys.argv:
        mode = "text"
    elif "--chars" in sys.argv:
        mode = "chars"
    else:
        CLIPresenter.display_message("Оберіть режим роботи:\n1. text\n2. chars")
        choice = CLIPresenter.prompt_input("Введіть режим: ").lower()
        mode = "text" if "text" in choice or choice == "1" else "chars"

    CLIPresenter.display_message(f"=== Активовано режим: {mode.upper()} ===")
    interpreter = CommandInterpreter(mode)

    while True:
        try:
            line = CLIPresenter.prompt_input("> ")
            if line in ["exit", "quit"]:
                break
            interpreter.interpret(line)
        except Exception as e:
            CLIPresenter.show_error(str(e))