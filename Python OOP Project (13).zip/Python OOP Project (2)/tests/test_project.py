import unittest
from unittest.mock import patch
from core.characters import CharacterManager
from core.text import create_character_document
from infra.web_api import GenshinWebAPI

class TestFinalIteration(unittest.TestCase):

    @patch('infra.web_api.urllib.request.urlopen')
    def test_web_api_mock(self, mock_urlopen):
        mock_response = mock_urlopen.return_value.__enter__.return_value
        mock_response.read.return_value = b'["amber"]'
        
        chars = GenshinWebAPI.get_characters_list()
        self.assertEqual(chars, ["amber"])

    def test_character_and_structured_text(self):
        char_mgr = CharacterManager()
        api_data = {
            "name": "Amber",
            "title": "Outrider",
            "description": "Test description",
            "combat-talents": [{"name": "Shot", "description": "Fires an arrow"}]
        }
        
        char = char_mgr.add_character_from_api(api_data)
        self.assertEqual(char.name, "Amber")
        self.assertEqual(len(char.abilities), 1)

        # Перевірка представлення через деревовидну структуру тексту
        doc = create_character_document(char)
        rendered = doc.render()
        self.assertIn("Amber", rendered)
        self.assertIn("Outrider", rendered)
        self.assertIn("Fires an arrow", rendered)

if __name__ == "__main__":
    unittest.main()