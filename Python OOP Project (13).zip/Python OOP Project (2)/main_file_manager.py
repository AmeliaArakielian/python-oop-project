from core.file_manager_state import FileManagerContext

def run_console_manager():
    print("=== Консольний файловий менеджер та редактор (Практична №12) ===")
    print("Доступні початкові команди: ls, cd <path>, open <filename>, exit")
    
    context = FileManagerContext()

    while not context.exit_app:
        try:
            prompt = context.get_prompt()
            line = input(prompt)
            result = context.execute(line)
            if result:
                print(result)
        except (KeyboardInterrupt, EOFError):
            print("\nВихід із програми.")
            break

if __name__ == "__main__":
    run_console_manager()
# Це тестовий коментар для ПР 12