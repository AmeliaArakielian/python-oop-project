from cli.arg_parser import ArgParser

class CLI:
    """Фасад командного інтерфейсу."""
    def __init__(self, context):
        self.context = context
        self.strategies = {}
        self.parser = ArgParser()

    def use_strategy(self, strategy):
        """Реєструє стратегію команд."""
        for selector in strategy.get_command_selectors():
            self.strategies[selector] = strategy

    def exec_command(self, raw_string: str) -> str:
        """Інтерпретує та виконує команду через відповідну стратегію."""
        parsed_args = self.parser.parse_args(raw_string)
        if not parsed_args.command:
            return ""
        
        strategy = self.strategies.get(parsed_args.command)
        if strategy:
            return strategy.execute(parsed_args, self.context)
        return f"Невідома команда: '{parsed_args.command}'. Введіть 'help' для довідки."

    def display(self, data) -> str:
        """Стандартизований вивід даних (рендеринг у консоль)."""
        return str(data)