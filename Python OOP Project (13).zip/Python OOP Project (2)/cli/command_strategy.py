from abc import ABC, abstractmethod
from cli.arg_parser import Args


class ICommandStrategy(ABC):
    @abstractmethod
    def execute(self, args: Args, context) -> str:
        pass

    @abstractmethod
    def get_command_selectors(self) -> list:
        """Повертає список команд, які обробляє ця стратегія."""
        pass


class CharacterCatalogStrategy(ICommandStrategy):
    def get_command_selectors(self) -> list:
        # Реєструємо всі доступні команди для цієї стратегії
        return ["list_chars", "show_char", "create_char", "api_list", "api_parse", "save_data"]

    def execute(self, args: Args, context) -> str:
        cmd = args.command

        # 1. Робота з локальним каталогом
        if cmd == "list_chars":
            chars = context.char_mgr.characters
            if not chars:
                return "Локальний каталог персонажів порожній."
            lines = ["Доступні локальні персонажі:"]
            for name in chars:
                lines.append(f"  - {name}")
            return "\n".join(lines)

        elif cmd == "show_char":
            if not args.args:
                return "Помилка: вкажіть ім'я персонажа. Приклад: show_char Aragorn"
            name = args.args[0]
            char = context.char_mgr.characters.get(name)
            if not char:
                return f"Персонажа '{name}' не знайдено в локальному каталозі."
            return (
                f"Персонаж: {char.name}\n"
                f"Титул: {char.title}\n"
                f"HP: {char.hp}, Атака: {char.attack}\n"
                f"Опис: {char.description}"
            )

        elif cmd == "create_char":
            if len(args.args) < 2:
                return "Помилка: вкажіть ім'я та титул. Приклад: create_char Legolas Elf"
            from core.characters import GameCharacter
            name, title = args.args[0], " ".join(args.args[1:])
            context.char_mgr.characters[name] = GameCharacter(
                name=name, uid=name.lower(), title=title, description="Створено через CLI"
            )
            return f"Створено та додано персонажа: {name} ({title})"

        # 2. Робота з парсингом JSON із Genshin API (Практична №14)
        elif cmd == "api_list":
            ids = context.catalog_service.get_available_ids()
            preview = ", ".join(ids[:15])
            more = f" ... (всього {len(ids)})" if len(ids) > 15 else ""
            return f"Доступні ID персонажів з API: {preview}{more}"

        elif cmd == "api_parse":
            if not args.args:
                return "Помилка: вкажіть ID персонажа з API. Приклад: api_parse diluc"
            char_id = args.args[0]
            model = context.catalog_service.get_character_model(char_id)
            if not model:
                return f"Не вдалося отримати або розпарсити JSON для '{char_id}'."
            return f"Успішно сформовано ViewModel:\n{model.format_card()}"

        elif cmd == "save_data":
            return "Дані каталогу та кеш ViewModel успішно збережено."

        return f"Невідома команда: '{cmd}'. Введіть 'help' для списку команд."