import shlex

class Args:
    """Об'єктне представлення розпарсених аргументів командного рядка."""
    def __init__(self, command: str, raw_args: list):
        self.command = command
        self.args = raw_args

    def __repr__(self):
        return f"Args(cmd={self.command}, args={self.args})"


class ArgParser:
    """Парсер термінального вводу користувача."""
    @staticmethod
    def parse_args(raw_string: str) -> Args:
        if not raw_string.strip():
            return Args("", [])
        parts = shlex.split(raw_string.strip())
        return Args(parts[0], parts[1:])