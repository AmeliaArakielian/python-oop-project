from infra.display import ConsoleDisplay

class CLIPresenter:
    """Модуль, що відповідає за ввід та вивід інформації в консоль."""
    
    @staticmethod
    def prompt_input(prompt_text: str = "> ") -> str:
        return input(prompt_text).strip()

    @staticmethod
    def display_output(text: str):
        ConsoleDisplay.show_message(text)

    @staticmethod
    def display_message(msg: str):
        """Аліас для сумісності з різними викликами у main."""
        ConsoleDisplay.show_message(msg)