import shlex
from infra.web_api import GenshinWebAPI
from core.characters import CharacterManager
from core.text import create_character_document
from cli.presenter import CLIPresenter

class CommandInterpreter:
    def __init__(self, mode: str):
        self.mode = mode
        self.char_mgr = CharacterManager()

    def interpret(self, line: str):
        if not line:
            return
        parts = shlex.split(line)
        cmd = parts[0]
        args = parts[1:]

        if self.mode == "chars":
            self._handle_chars(cmd, args)
        else:
            CLIPresenter.display_output("Введіть 'list_api', 'create_api <name>', 'equip <char> <weapon>', або 'show_doc <char>'")

    def _handle_chars(self, cmd: str, args: list):
        if cmd == "list_api":
            CLIPresenter.display_output("Отримання списку з віддаленого API...")
            chars = GenshinWebAPI.get_characters_list()
            weapons = GenshinWebAPI.get_weapons_list()
            CLIPresenter.display_output(f"Доступні персонажі (перші 5): {chars[:5]}")
            CLIPresenter.display_output(f"Доступна зброя (перші 5): {weapons[:5]}")
        
        elif cmd == "create_api":
            if not args:
                CLIPresenter.display_output("Використання: create_api <character_name>")
                return
            char_name = args[0]
            details = GenshinWebAPI.get_character_details(char_name)
            if details:
                char = self.char_mgr.add_character_from_api(details)
                CLIPresenter.display_output(f"Віртуального персонажа '{char.name}' успішно створено!")
            else:
                CLIPresenter.display_output("Не вдалося завантажити дані про персонажа.")

        elif cmd == "equip":
            if len(args) < 2:
                CLIPresenter.display_output("Використання: equip <char_id> <weapon_name>")
                return
            char_id, weapon_name = args[0], args[1]
            w_details = GenshinWebAPI.get_weapon_details(weapon_name)
            if w_details:
                item = self.char_mgr.add_weapon_from_api(weapon_name, w_details)
                self.char_mgr.assign_item_to_character(char_id, item.uid)
                CLIPresenter.display_output(f"Зброю '{weapon_name}' успішно екіпіровано на '{char_id}'!")
            else:
                CLIPresenter.display_output("Не вдалося завантажити зброю.")

        elif cmd == "show_doc":
            if not args:
                CLIPresenter.display_output("Використання: show_doc <char_id>")
                return
            char_id = args[0]
            char = self.char_mgr.characters.get(char_id)
            if char:
                doc = create_character_document(char)
                CLIPresenter.display_output("\n" + doc.render(show_id=True))
            else:
                CLIPresenter.display_output("Персонажа не знайдено у системі.")
        elif cmd == "save":
            if not args:
                CLIPresenter.display_output("Використання: save <character_name>")
                return
            char_name = args[0]
            char = self.char_mgr.characters.get(char_name)
            if char:
                char.save_state()
                CLIPresenter.display_output(f"Збережено стан персонажа {char_name}.")
            else:
                CLIPresenter.display_output(f"Персонажа '{char_name}' не знайдено серед створених.")

        elif cmd == "restore":
            if not args:
                CLIPresenter.display_output("Використання: restore <character_name>")
                return
            char_name = args[0]
            char = self.char_mgr.characters.get(char_name)
            if char:
                try:
                    char.restore_state()
                    CLIPresenter.display_output(f"Відновлено стан персонажа {char_name}.")
                except Exception as e:
                    CLIPresenter.display_output(f"Немає збережень для відновлення: {e}")
            else:
                CLIPresenter.display_output(f"Персонажа '{char_name}' не знайдено.")

        elif cmd == "combat":
            if not args:
                CLIPresenter.display_output("Використання: combat <character_name>")
                return
            char_name = args[0]
            char = self.char_mgr.characters.get(char_name)
            if char:
                result = char.perform_combat()
                CLIPresenter.display_output(result)
            else:
                CLIPresenter.display_output(f"Персонажа '{char_name}' не знайдено.")
        else:
            CLIPresenter.display_output(f"Невідома команда: {cmd}")