import urllib.request
import json
from typing import List, Dict, Any

class GenshinWebAPI:
    """Модуль WebApi для взаємодії зі стороннім сервісом та стягування інформації."""
    BASE_URL = "https://genshin.jmp.blue"

    @classmethod
    def get_characters_list(cls) -> List[str]:
        """Отримує список доступних персонажів з API."""
        try:
            url = f"{cls.BASE_URL}/characters"
            req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
            with urllib.request.urlopen(req) as response:
                return json.loads(response.read().decode('utf-8'))
        except Exception as e:
            print(f"Помилка запиту списку персонажів: {e}")
            return []

    @classmethod
    def get_character_details(cls, char_name: str) -> Dict[str, Any]:
        """Отримує деталізовану інформацію про конкретного персонажа."""
        try:
            url = f"{cls.BASE_URL}/characters/{char_name}"
            req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
            with urllib.request.urlopen(req) as response:
                return json.loads(response.read().decode('utf-8'))
        except Exception as e:
            print(f"Помилка запиту персонажа {char_name}: {e}")
            return {}

    @classmethod
    def get_weapons_list(cls) -> List[str]:
        """Отримує список доступної зброї."""
        try:
            url = f"{cls.BASE_URL}/weapons"
            req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
            with urllib.request.urlopen(req) as response:
                return json.loads(response.read().decode('utf-8'))
        except Exception as e:
            print(f"Помилка запиту списку зброї: {e}")
            return []

    @classmethod
    def get_weapon_details(cls, weapon_name: str) -> Dict[str, Any]:
        """Отримує детальну інформацію про зброю (предмет)."""
        try:
            url = f"{cls.BASE_URL}/weapons/{weapon_name}"
            req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
            with urllib.request.urlopen(req) as response:
                return json.loads(response.read().decode('utf-8'))
        except Exception as e:
            print(f"Помилка запиту зброї {weapon_name}: {e}")
            return {}