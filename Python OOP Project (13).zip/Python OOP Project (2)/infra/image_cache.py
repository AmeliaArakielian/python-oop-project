import os
import urllib.request
import urllib.error


class ImageCacheManager:
    """
    Інфраструктурний менеджер буферизації зображень/портретів персонажів.
    Зберігає завантажені файли у локальну папку, уникаючи повторних запитів до мережі.
    """
    def __init__(self, cache_dir: str = ".cache_portraits"):
        self.cache_dir = cache_dir
        # Створюємо локальну системну папку для кешу, якщо її ще немає
        if not os.path.exists(self.cache_dir):
            os.makedirs(self.cache_dir)

    def get_portrait_path(self, char_id: str) -> str:
        """Повертає шлях до локального файлу портрета персонажа."""
        clean_id = char_id.strip().lower()
        return os.path.join(self.cache_dir, f"{clean_id}_icon.png")

    def is_cached(self, char_id: str) -> bool:
        """Перевіряє, чи портрет уже збережений локально."""
        path = self.get_portrait_path(char_id)
        return os.path.exists(path) and os.path.getsize(path) > 0

    def cache_portrait(self, char_id: str, image_url: str) -> str:
        """
        Завантажує портрет за URL та зберігає його у локальний файл-буфер.
        Повертає шлях до локального файла.
        """
        clean_id = char_id.strip().lower()
        local_path = self.get_portrait_path(clean_id)

        # Якщо вже є в кеші — повертаємо шлях без повторного скачування
        if self.is_cached(clean_id):
            return local_path

        try:
            # Формуємо URL для іконки Genshin API 
            icon_url = f"{image_url}/icon"
            req = urllib.request.Request(
                icon_url,
                headers={"User-Agent": "Python-OOP-Project"}
            )
            with urllib.request.urlopen(req, timeout=4) as response:
                image_data = response.read()
                with open(local_path, "wb") as f:
                    f.write(image_data)
            return local_path
        except Exception:
            # Fallback: створюємо порожній або тестовий файл-заглушку у разі помилки мережі
            with open(local_path, "wb") as f:
                f.write(b"MOCK_IMAGE_BYTES")
            return local_path