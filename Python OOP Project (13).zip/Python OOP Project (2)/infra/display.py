class ConsoleDisplay:
    """Клас, що абстрагує взаємодію з консоллю[cite: 5]."""
    @staticmethod
    def show_message(msg: str):
        print(msg)

    @staticmethod
    def show_error(err: str):
        print(f"[ПОМИЛКА]: {err}")