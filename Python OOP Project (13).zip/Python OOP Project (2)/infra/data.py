import json
import os

class StorageManager:
    """Модуль для серіалізації та збереження стану[cite: 5]."""
    @staticmethod
    def save_state(filename: str, data: dict):
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=4)

    @staticmethod
    def load_state(filename: str) -> dict:
        if os.path.exists(filename):
            with open(filename, 'r', encoding='utf-8') as f:
                return json.load(f)
        return {}